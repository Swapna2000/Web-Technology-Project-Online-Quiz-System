-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2020 at 08:02 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'kpswapna03@gmail.com', 'gowda');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('5a141a', '5a141aa'),
('5a141b', '5a142aa'),
('5a141c', '5a143ac'),
('5a141d', '5a144ad'),
('5a141e', '5a145ad'),
('5a141f', '5a146aa'),
('5a141g', '5a147aa'),
('5a141h', '5a148aa'),
('5a141i', '5a149ab'),
('5a141j', '5a140ab'),
('6b142a', '6b141ad'),
('6b142b', '6b142ac'),
('6b142c', '6b143ab'),
('6b142d', '6b144ad'),
('6b142e', '6b145aa'),
('6b142f', '6b146ab'),
('6b142g', '6b147ad'),
('6b142h', '6b148ab'),
('6b142i', '6b149aa'),
('6b142j', '6b140ac');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('suryaprasadtripathy8@gmail.com', '5a141', 22, 10, 8, 2, '2020-06-03 16:56:00'),
('pinky@gmail.com', '5a141', 30, 10, 10, 0, '2020-06-03 16:57:45'),
('priyanka@gmail.com', '5a141', 22, 10, 8, 2, '2020-06-03 16:59:06'),
('suryaprasadtripathy8@gmail.com', '6b142', 26, 10, 9, 1, '2020-06-03 17:17:26');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('5a141a', 'Personal Home Page', '5a141aa'),
('5a141a', 'Private Home Page', '5a141ab'),
('5a141a', 'Pretext Hypertext Processor', '5a141ac'),
('5a141a', 'Preprocessor Home Page', '5a141ab'),
('5a141b', 'Rasmus Lerdorf', '5a142aa'),
('5a141b', 'Willam Makepiece', '5a142ab'),
('5a141b', 'Drek Kolkevi', '5a142ac'),
('5a141b', 'List Barely', '5a142ad'),
('5a141c', '.html', '5a143aa'),
('5a141c', '.ph', '5a143ab'),
('5a141c', '.php', '5a143ac'),
('5a141c', '.xml', '5a143ad'),
('5a141d', 'for loop', '5a144aa'),
('5a141d', 'do-while loop', '5a144ab'),
('5a141d', 'foreach loop', '5a144ac'),
('5a141d', 'All of the above', '5a144ad'),
('5a141e', 'echo (â€œHello Worldâ€);', '5a145aa'),
('5a141e', 'print (â€œHello Worldâ€);', '5a145ab'),
('5a141e', 'printf (â€œHello Worldâ€);', '5a145ac'),
('5a141e', 'All of the above', '5a145ad'),
('5a141f', 'file()', '5a146aa'),
('5a141f', 'arr_file()', '5a146ab'),
('5a141f', 'arrfile()', '5a146ac'),
('5a141f', 'file_arr()', '5a146ad'),
('5a141g', 'Magic Function', '5a147aa'),
('5a141g', 'Inbuilt Function', '5a147ab'),
('5a141g', 'Default Function', '5a147ac'),
('5a141g', 'User Defined Function', '5a147ad'),
('5a141h', 'CREATE TABLE table_name (column_name column_type);', '5a148aa'),
('5a141h', 'CREATE table_name (column_type column_name);', '5a148ab'),
('5a141h', 'CREATE table_name (column_name column_type);', '5a148ac'),
('5a141h', 'CREATE TABLE table_name (column_type column_name);', '5a148ad'),
('5a141i', 'get_array() and get_row()', '5a149aa'),
('5a141i', 'fetch_array() and fetch_row()', '5a149ab'),
('5a141i', 'get_array() and get_column()', '5a149ac'),
('5a141i', 'fetch_array() and fetch_column()', '5a149ad'),
('5a141j', 'explode()', '5a140aa'),
('5a141j', 'implode()', '5a140ab'),
('5a141j', 'concat()', '5a140ac'),
('5a141j', 'concatenate()', '5a140ad'),
('6b142a', '32 bits', '6b141aa'),
('6b142a', '128 bytes', '6b141ab'),
('6b142a', '64 bits', '6b141ac'),
('6b142a', '16 bytes', '6b141ad'),
('6b142b', 'IP', '6b142aa'),
('6b142b', 'TCP', '6b142ab'),
('6b142b', 'UDP', '6b142ac'),
('6b142b', 'ARP', '6b142ad'),
('6b142c', 'Session layer', '6b143aa'),
('6b142c', 'Physical layer', '6b143ab'),
('6b142c', 'Data Link layer', '6b143ac'),
('6b142c', 'Application layer', '6b143ad'),
('6b142d', '12.0.0.1', '6b144aa'),
('6b142d', '168.172.19.39', '6b144ab'),
('6b142d', '172.15.14.36', '6b144ac'),
('6b142d', '192.168.24.43', '6b144ad'),
('6b142e', 'Application', '6b145aa'),
('6b142e', 'Presentation', '6b145ab'),
('6b142e', 'Session', '6b145ac'),
('6b142e', 'Transport', '6b145ad'),
('6b142f', 'VTP', '6b146aa'),
('6b142f', 'STP', '6b146ab'),
('6b142f', 'RIP', '6b146ac'),
('6b142f', 'CDP', '6b146ad'),
('6b142g', '14', '6b147aa'),
('6b142g', '15', '6b147ab'),
('6b142g', '16', '6b147ac'),
('6b142g', '30', '6b147ad'),
('6b142h', '255.255.255.192', '6b148aa'),
('6b142h', '255.255.255.224', '6b148ab'),
('6b142h', '255.255.255.240', '6b148ac'),
('6b142h', '255.255.255.248', '6b148ad'),
('6b142i', '6', '6b149aa'),
('6b142i', '8', '6b149ab'),
('6b142i', '30', '6b149ac'),
('6b142i', '32', '6b149ad'),
('6b142j', '127.0.0.0', '6b140aa'),
('6b142j', '1.0.0.127', '6b140ab'),
('6b142j', '127.0.0.1', '6b140ac'),
('6b142j', '127.0.0.255', '6b14ad');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('5a141', '5a141a', 'What does PHP stand for?', 4, 1),
('5a141', '5a141b', 'Who is the father of PHP?', 4, 2),
('5a141', '5a141c', 'PHP files have a default file extension of.', 4, 3),
('5a141', '5a141d', 'Which of the looping statements is/are supported by PHP?', 4, 4),
('5a141', '5a141e', 'Which of the following PHP statements will output Hello World on the screen?', 4, 5),
('5a141', '5a141f', 'Which one of the following function is capable of reading a file into an array?', 4, 6),
('5a141', '5a141g', 'A function in PHP which starts with __ (double underscore) is know as..', 4, 7),
('5a141', '5a141h', 'Which one of the following statements is used to create a table?', 4, 8),
('5a141', '5a141i', 'Which of the methods are used to manage result sets using both associative and indexed arrays?', 4, 9),
('5a141', '5a141j', 'Which one of the following functions can be used to concatenate array elements to form a single delimited string?', 4, 10),
('6b142', '6b142a', 'How long is an IPv6 address?', 4, 1),
('6b142', '6b142b', 'Which protocol does DHCP use at the Transport layer?', 4, 2),
('6b142', '6b142c', 'Where is a hub specified in the OSI model?', 4, 3),
('6b142', '6b142d', 'Which of the following is private IP address?', 4, 4),
('6b142', '6b142e', 'If you use either Telnet or FTP, which is the highest layer you are using to transmit data?', 4, 5),
('6b142', '6b142f', 'Which of the following is a layer 2 protocol used to maintain a loop-free network?', 4, 6),
('6b142', '6b142g', 'What is the maximum number of IP addresses that can be assigned to hosts on a local subnet that uses the 255.255.255.224 subnet mask?', 4, 7),
('6b142', '6b142h', 'You need to subnet a network that has 5 subnets, each with at least 16 hosts. Which classful subnet mask would you use?', 4, 8),
('6b142', '6b142i', 'You have an interface on a router with the IP address of 192.168.192.10/29. Including the router interface, how many hosts can have IP addresses on the LAN attached to the router interface?', 4, 9),
('6b142', '6b142j', 'To test the IP stack on your local host, which IP address would you ping?\r\n\r\n', 4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `date`) VALUES
('5a141', 'Php & Mysqli', 3, 1, 10, '2020-08-03 16:46:56'),
('6b142', 'Ip Networking', 3, 1, 10, '2020-08-03 17:02:22');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('pinky@gmail.com', 30, '2020-06-03 16:57:45'),
('priyanka@gmail.com', 22, '2020-06-03 16:59:06');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `college`, `email`, `password`) VALUES
('Swagatika ', 'cit,Tumkur', 'pinky@gmail.com', 'pinky'),
('sumathi', 'cit, Tumkur', 'priyanka@gmail.com', 'pinka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
